<?php

namespace Modules\Like\Database\Seeders;

use Illuminate\Database\Seeder;

class LikeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
