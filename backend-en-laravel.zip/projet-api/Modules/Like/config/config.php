<?php

return [
    'name' => 'Like',
];
