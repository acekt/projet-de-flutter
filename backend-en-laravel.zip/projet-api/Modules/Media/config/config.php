<?php

return [
    'name' => 'Media',
];
