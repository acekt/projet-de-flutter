<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Comment\\Providers\\CommentServiceProvider',
    2 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    3 => 'Modules\\Like\\Providers\\LikeServiceProvider',
    4 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    5 => 'Modules\\Post\\Providers\\PostServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Comment\\Providers\\CommentServiceProvider',
    2 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    3 => 'Modules\\Like\\Providers\\LikeServiceProvider',
    4 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    5 => 'Modules\\Post\\Providers\\PostServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);